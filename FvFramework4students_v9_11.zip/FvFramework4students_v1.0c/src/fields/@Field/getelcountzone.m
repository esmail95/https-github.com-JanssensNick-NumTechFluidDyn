function n = getelcountzone(This)

   n = This.elcountzone;

end