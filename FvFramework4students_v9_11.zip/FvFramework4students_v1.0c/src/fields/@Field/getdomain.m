function DomainObj = getdomain(This)

   DomainObj = This.dom;

end