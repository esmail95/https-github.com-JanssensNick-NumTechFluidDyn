function flag = isvector(This)

   flag = This.isvec;

end
