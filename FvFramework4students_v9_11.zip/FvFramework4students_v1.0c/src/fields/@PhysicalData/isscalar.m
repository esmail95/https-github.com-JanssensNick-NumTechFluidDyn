function flag = isscalar(This)

   flag = This.isscal;

end
