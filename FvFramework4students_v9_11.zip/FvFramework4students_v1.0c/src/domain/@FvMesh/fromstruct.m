function Obj = fromstruct(mStruct)
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
%
% STATIC METHOD FvMesh.fromstruct(mStruct)
% 
% Facory method for creating an FvMesh object from data in a struct.
%
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        
	Obj = FvMesh(mStruct);
        
end 