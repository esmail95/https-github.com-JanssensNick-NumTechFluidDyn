function DomObj = getdomain(This)

    DomObj = This.dom;

end