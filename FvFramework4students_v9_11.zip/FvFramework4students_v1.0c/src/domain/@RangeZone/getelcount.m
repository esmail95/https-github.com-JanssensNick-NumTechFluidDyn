function n = getelcount(This)

    n = This.elcount;

end