function Obj = newdomain(MeshObj,id)

    Obj = FvDomain(MeshObj,id);

end