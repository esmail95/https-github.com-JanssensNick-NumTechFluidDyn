function reset(this)

   this.adata = zeros(this.nnz,1);
	this.bdata = zeros(this.n,1);
   
end