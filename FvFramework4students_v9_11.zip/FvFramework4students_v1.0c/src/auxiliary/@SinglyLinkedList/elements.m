function it = elements(this)
% Returns a new iterator

    it = SinglyLinkedListIterator(this.Head);

end % SinglyLinkedList.elements