function flag = istensor(This)

   flag = This.istens;

end
