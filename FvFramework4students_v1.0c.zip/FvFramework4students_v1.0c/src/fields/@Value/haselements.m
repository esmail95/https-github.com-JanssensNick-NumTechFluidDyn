function haselflag = haselements(This)

   haselflag = (This.elcount > 0);

end