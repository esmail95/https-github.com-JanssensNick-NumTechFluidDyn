function elcount = getelcount(This)

   elcount = This.elcount;

end