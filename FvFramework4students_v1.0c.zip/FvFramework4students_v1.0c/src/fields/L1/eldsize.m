function s = eldsize(rank,dim)
% returns the datasize of an entity with given rank and dimension.

s = dim^rank;

end