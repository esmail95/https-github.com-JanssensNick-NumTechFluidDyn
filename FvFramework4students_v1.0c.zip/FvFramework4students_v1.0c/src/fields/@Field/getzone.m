function ZoneObj = getzone(This)

   ZoneObj = This.zone;

end