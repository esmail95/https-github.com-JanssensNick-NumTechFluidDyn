function setnext(this,NextNode_)
        
    this.Next = NextNode_;
        
end % SinglyLinkedListNode.setnext