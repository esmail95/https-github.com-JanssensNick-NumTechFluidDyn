function str = logical2string(log)                
    if log
        str = 'yes';
    else
        str = 'no';
    end                
end