function clearlist(this)

    this.Head = [];
    this.nElem = 0;

end % SinglyLinkedList.clearlist
