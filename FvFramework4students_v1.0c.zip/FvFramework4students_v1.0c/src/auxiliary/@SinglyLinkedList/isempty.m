function flag = isempty(this)

    flag = isempty(this.Head);

end % SinglyLinkedList.isempty