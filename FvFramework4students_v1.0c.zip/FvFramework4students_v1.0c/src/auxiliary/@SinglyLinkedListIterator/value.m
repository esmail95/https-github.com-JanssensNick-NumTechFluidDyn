function Data_ = value(this)

    Data_ = this.Current.Data;

end % SinglyLinkedListIterator.value