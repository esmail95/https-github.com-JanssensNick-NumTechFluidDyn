function flag = hasmoreelements(this)

    flag = ~isempty(this.Current);

end % SinglyLinkedListIterator.hasmoreelements