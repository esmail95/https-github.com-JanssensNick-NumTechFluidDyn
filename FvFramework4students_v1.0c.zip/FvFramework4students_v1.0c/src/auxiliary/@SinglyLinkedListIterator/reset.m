function reset(this)

    this.Current = this.Head;
    
end % SinglyLinkedListIterator.reset