function dim = getdim(This)
   
    dim = This.dom.dim;

end