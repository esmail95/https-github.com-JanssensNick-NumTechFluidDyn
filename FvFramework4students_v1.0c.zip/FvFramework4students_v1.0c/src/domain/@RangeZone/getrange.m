function range = getrange(This)

    range = This.range;    

end