function cdata = getallcoords(This)

   cdata = This.dom.vCoord;

end