function cdata = getallcoords(This)

   cdata = This.dom.fCoord;

end