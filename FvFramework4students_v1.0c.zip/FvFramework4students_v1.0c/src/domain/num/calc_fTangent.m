function fTangent = calc_fTangent(nF,fNormal)
   fTangent = [fNormal(2,:);-fNormal(1,:)];
end



